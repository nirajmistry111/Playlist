package playlist.com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class S2 extends HttpServlet {
	
	
	protected void processRequest(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("text/html");
		// USING TRy with resource if not to use catch block 
		try(PrintWriter writer  = resp.getWriter()){
			
			
			
			int number1 = Integer.parseInt(req.getParameter("Num1"));
			int number2 = Integer.parseInt(req.getParameter("Num2"));
			
			int multiply = (number1 * number2) ;
			
			
			// By setting object we are coverting the int to object 
			// Set or get Attribute will convert it in object so we need to conver
			// in respective data type   
			
			int sum = (int)req.getAttribute("t");
			writer.println("<h1>");
			writer.println(" Sum is = "  + sum);
			writer.println("<br>");
			writer.println(" Multiplication is = "  + multiply);
			writer.println("</h1>");
			
		}
		
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(req, resp);
	}

}
