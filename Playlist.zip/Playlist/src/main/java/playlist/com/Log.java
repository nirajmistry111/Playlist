package playlist.com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Log extends HttpServlet{
	
	
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
	//	If you get successful login you will be forwarded here and from here to calculation page
		
		resp.setContentType("text/html");
		
		// CREATING OBJECT OF PRINTWRITER IN WHICH WRITER WILL STORE ALL RESPONSE OF INPUT 
				
				
				PrintWriter writer = resp.getWriter();
				writer.println("<h1> You Have succesfully login  </h1>");
				
				
				 RequestDispatcher rd = req.getRequestDispatcher("Home2.jsp"); 
				 rd.include(req,resp);
			
				
			
	}
	
}
