package playlist.com;


import java.util.*;
import java.io.*;

import java.sql.*;

import javax.servlet.*;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.*;


@MultipartConfig
public class Login extends HttpServlet{
	 String em ;
		String pa;
	
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		
		resp.setContentType("text/html");
		
		// we are using resp as we need to write the response that server will give on request of client
		
		PrintWriter writer = resp.getWriter();
		writer.println("<h1> Welcome to Login Page </h1>");
		
		
		// As client is requesting we as a server will accept the request and store in string
		
		
		String Emails = req.getParameter("email");
		String pswd = req.getParameter("pass");	
	
		
		try{

		    // Load class
		    Class.forName("com.mysql.cj.jdbc.Driver");
		    

		    // Create ConnectionProvider
		    String url = "jdbc:mysql://localhost:3306/employee_data";
		    String username = "root";
		    String passwords = "Rekha@9426";

		    Connection con = DriverManager.getConnection(url,username,passwords);
		    
		    String q = "Select * from employee_data1 WHERE Email = ? AND Password = ?";

		//  Create Statement object
		     PreparedStatement stmt = con.prepareStatement(q);
		     
		     stmt.setString(1, Emails);
		     stmt.setString(2, pswd);
		     
		 // ResultSet is use to retrive coloum values from database 
		     
		     ResultSet rs = stmt.executeQuery();
		     
	
		     if(rs.next()) 
		     {
		     writer.println("<h1> You have succesfully Login </h1>");
				
				  HttpSession session = req.getSession(); session.setAttribute("username",
				  Emails);
				 
    		 RequestDispatcher rd=req.getRequestDispatcher("Log.java");
    		 rd.forward(req, resp);
    		
    	 }else {
    		 writer.println("<h1>Credentials are not valid </h1>");
    		 writer.println("<h1>Click on Register Page to get back to Register Page </h1>");
    		 writer.println("<h1>Re-Enter email and password </h1>");
    		 RequestDispatcher rd=req.getRequestDispatcher("Login.jsp");
    		 rd.include(req, resp);
    		 
    	 }


		    con.close();
		    
		}catch(Exception e){
		    System.out.println(e);
		}
		    
		
		
		
	}

}

